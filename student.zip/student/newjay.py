from flask import Flask, jsonify, request, json
app = Flask(__name__)

with open('student.json') as f:
	results = json.load(f)
#students = [{'name' : 'Ma.Leah', 'gender' : 'Female', 'Age':'19'}, {'name' : 'Geronyl', 'gender':'Male', 'Age':'21'}, {'name' : 'Leejames', 'gender':'trans', 'age':'ice'}]

@app.route('/',methods =['GET'])
def test():
	return jsonify({'message' : 'It Works!, add /stud for GET or Try using the newjay_req.py for GET, POST, PUT, and DELETE requests'})

@app.route('/stud', methods=['GET'])
def returnAll():
	return jsonify({'results' : results})

@app.route('/stud=<string:name>', methods=['GET'])
def returnOne(name):
	studs = [student for student in results['students'] if student['name']==name]
	
	return jsonify({'student' : studs[0]})


@app.route('/stud',methods= ['POST'])
def addOne():
	stud = {'name' : request.json['name'], 'gender': request.json['gender'], 'Age': request.json['Age']}
	results['students'].append(stud)
	return jsonify({'students' : results['students']})

# @app.route('/stud/<string:name> :', methods = ['POST'])
# def addAttr(name):
	
# 	stud = [student for student in students if student['name'] == name]
# 	ins = {'id' : request.json['id']}
# 	stud[0].append(ins)
	
# 	return jsonify({'student' : stud[0]})


@app.route('/stud=<string:name>', methods = ['PUT'])#in this route http://127.0.0.1/stud/{name you want to be replace with somethin} 
def editOne(name):
	studs = [student for student in results['students'] if student['name'] == name]
	studs[0]['name'] = request.json['name']
	studs[0]['gender'] = request.json['gender']
	studs[0]['Age'] = request.json['Age']
	return jsonify({'student' : studs[0]})

@app.route('/stud=<string:name>', methods = ['DELETE'])
def removeOne(name):
	stud = [student for student in results['students'] if student['name'] == name]
	results['students'].remove(stud[0])
	return jsonify({'students' : results['students']})


if __name__ == '__main__':
	app.run(debug = True,port=8080)