from pprint import pprint
import requests, json



while (True):
	choice = raw_input("[GET] [POST] [PUT] [DELETE] [X]\n\n>>>")
	if choice == 'GET':
		x=raw_input("[A] -for All\n[B] -for searching specific student\n[x] -Exit\n\n>>>")
		if x == 'A':
			req = requests.get("http://127.0.0.1:8080/stud")
			obj=req.json()
			print(pprint(obj))
		elif x == 'B':
			name=raw_input("enter student's name:")
			req = requests.get("http://127.0.0.1:8080/stud="+name)
			obj=req.json()
			print(pprint(obj))
		elif x=='X':
			pass
	elif choice == 'POST':

		name  = raw_input("name: ")
		gender  = raw_input("gender: ")
		age  = raw_input("Age: ")
		print "\nUse GET to check results"
		req = requests.post("http://127.0.0.1:8080/stud", json = {'name':name, 'gender':gender, 'Age':age}) 

	elif choice == 'PUT':

		name = raw_input("enter name: ")
		print "\nCHANGES:\n"
		newname = raw_input("name:")
		gender = raw_input("gender: ")
		age = raw_input("age: ")
		print "\nUse GET to check results"
		req = requests.put("http://127.0.0.1:8080/stud="+name, json={'name':newname, 'gender':gender, 'Age':age})

	elif choice == "DELETE":
		name = raw_input("enter name: ")
		print "\nUse GET to check results"
		req = requests.delete("http://127.0.0.1:8080/stud="+name)

	elif choice =='X':
		break
